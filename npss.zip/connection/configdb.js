var sql = require("mssql");

var exports = module.exports = {};

var config = {
  user: 'NPS_owner',
  password: 'u5N$ZNub4[4X',
  host: 'nps-classification-app.database.windows.net',
  database: 'NPS-Classification-APP-DB',
  dialect: 'mssql',
  
  options: {
    encrypt: true
  }
}


exports.sql = sql;
exports.config = config;