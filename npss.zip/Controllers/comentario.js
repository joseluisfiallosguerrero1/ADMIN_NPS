var db = require('./../connection/configdb');
var excel = require('excel4node');
var azure = require('azure-storage');
//var blobService = azure.createBlobService();
var excels = require('excel-stream')
var fs = require('fs')
var stream = require('stream');
const models = require('../Models');
const readXlsxFile = require('read-excel-file/node');
var fileService = azure.createBlobService(
    'laureatembiprod',
    'hmKIdn+H7HwAMK5pO42Fjom/Q/XJpppQvvwVJyX8r/W4tWuCFnoAvtNg3OX0M9rsM0miVuLOPkDt3U2jNmj1ug=='
);
var comentarios = models.Comentarios
var usuarios = models.Usuarios
var comentariosUsuarios = models.ComentariosUsuarios
var ComentarioPorHerramienta = models.ComentarioPorHerramienta


var Sequelize = require('sequelize');

exports.comentario = {
    create: function () {
        var p = new Promise(function (resolve, reject) {
            var control = false;
            var datetime = new Date();
            fileService.getBlobToStream('npstest', 'download.xlsx', fs.createWriteStream('download.xlsx'), function (error, serverBlob) {
                if (!error) {
                    // Blob available in serverBlob.blob variable
                    console.log("ffffffffffff");
                    console.log(serverBlob);
                    console.log("pedro");
                    readXlsxFile(fs.createReadStream('Book1.xlsx')).then((rows) => {
                        console.log("pedro2");
                        rows.forEach(element => {
                            console.log("aaaaaasssss");
                            console.log(element);
                            const comen = comentarios.create({
                                PreClasificacion: element[7],
                                Clasificacion: '',
                                Status: element[4],
                                Comentario: element[3],
                                NombreDeArchivo: 'book1',
                                Fecha: datetime,
                                Estado: 0,
                                Aspecto: 'xxx',
                                IdHerramienta: 1,
                                IdUsuario: 1,
                                Tema: 'xx',
                                Status: 0
                            }).then(res => {
                                if (element == rows[rows.length - 1]) {
                                    var respuesta = {
                                        success: 'true',

                                    };
                                    resolve(respuesta);
                                }
                            });

                        });
                    })


                } else {
                    console.log("aaaaaaaaaaaaaaaaaaa" + error);
                }
            });

            /*
            readXlsxFile(fs.createReadStream('Book1.xlsx')).then((rows) => {
              console.log("pedro2");
              rows.forEach(element => {
                  console.log("aaaaaasssss");
                  console.log(element);
              });
          })
          */

        });
        return p;
    },
    uploadToBlob: function (csv, name) {
        var p = new Promise(function (resolve, reject) {
            const ot = Buffer.from(csv, 'base64');

            var s = new stream.Readable();

            s.push(ot);
            s.push(null);

            fileService.createBlockBlobFromStream(
                'npstest',
                name,
                s,
                ot.length,
                error => {
                    if (!error) {
                        // file uploaded
                        var respuesta = {
                            success: true,
                            Msg: 'file uploaded'
                        };
                        resolve(respuesta);
                    } else {
                        var respuesta = {
                            success: false,
                            Msg: 'Error in input data',
                            err: error
                        };
                        resolve(respuesta);
                    }
                }
            );
        });
        return p;
    },
    LLenadoDeUsuarios: function () {
        var p = new Promise(function (resolve, reject) {

            var datetime = new Date();
            const usua = usuarios.destroy({
                where: {},
                truncate: true
            });
            usua.then(resolveresult => {
                fileService.getBlobToStream('npstest', 'usuarios.xlsx', fs.createWriteStream('usuarios.xlsx'), function (error, serverBlob) {
                    if (!error) {
                        // Blob available in serverBlob.blob variable
                        console.log("ffffffffffff");
                        console.log(serverBlob);
                        console.log("pedro");
                        readXlsxFile(fs.createReadStream('usuarios.xlsx')).then((rows) => {
                            console.log("pedro2");
                            rows.forEach(element => {
                                console.log("aaaaaasssss");
                                console.log(element);
                                console.log(element[0] + "0000");
                                console.log(element[1] + "1111");

                                const usuarioCreado = usuarios.create({
                                    Rol: 'Maestro',
                                    Contraseña: element[0],
                                    Usuario: element[1]
                                }).then(res => {
                                    if (element == rows[rows.length - 1]) {
                                        var respuesta = {
                                            success: 'true',

                                        };
                                        resolve(respuesta);
                                    }
                                });;
                            });
                        })


                    } else {
                        console.log("aaaaaaaaaaaaaaaaaaa" + error);
                    }
                });
            });


            /*
            readXlsxFile(fs.createReadStream('Book1.xlsx')).then((rows) => {
              console.log("pedro2");
              rows.forEach(element => {
                  console.log("aaaaaasssss");
                  console.log(element);
              });
          })
          */

        });
        return p;
    },
    Distribucion: function () {
        var p = new Promise(function (resolve, reject) {
            const users = usuarios.findAll({

            });
            users.then(resolveresult1 => {
                //   var Selection = JSON.parse(resolveresult1.Usuarios);
                //console.log(Selection[0]);
                const comentaries = comentarios.findAll({

                });
                comentaries.then(resolveresult2 => {
                    console.log(resolveresult1[0].dataValues.IdUsuario);
                    console.log(resolveresult1.length);
                    console.log(resolveresult2.length)
                    var tam = resolveresult1.length - 1;
                    var cont = 0;
                   
                    resolveresult2.forEach(element => {
                        console.log(element.dataValues.IdComentario );
                        var modify={
                            IdUsuario:resolveresult1[cont].dataValues.IdUsuario
                        }
                        console.log(modify);
                        const comi = comentarios
                            .update(modify, {
                                where: {
                                    IdComentario:element.dataValues.IdComentario 
                                }
                            }).then(res => {
                                if (element == resolveresult2[resolveresult2.length - 1]) {
                                    console.log(element.dataValues.IdComentario );
                                    console.log(resolveresult1[cont].dataValues.IdUsuario);
                                    var respuesta = {
                                        success: 'true',
                                    };
                                    resolve(respuesta);
                                }
                            });;
                        if (cont == tam) {
                            cont = 0;
                        } else {
                            cont = cont + 1;
                        }
                    });

                });
            });

        });


        /*
        readXlsxFile(fs.createReadStream('Book1.xlsx')).then((rows) => {
          console.log("pedro2");
          rows.forEach(element => {
              console.log("aaaaaasssss");
              console.log(element);
          });
      })
      */

        return p;
    },
    Clasificar: function (idComentario, modify) {
        var p = new Promise(function (resolve, reject) {
            console.log(modify);
            const comenta = comentarios
                .update(modify, {
                    where: {
                        IdComentario: idComentario
                    }
                })
                .catch(function (err) {
                    var respuesta = {
                        success: 'false',
                        Msg: 'The input data is incorrect'
                    };
                    resolve(respuesta);
                });
            comenta.then(resolves => {
                var condicion3 = comentarios
                    .findOne({
                        where: {
                            IdComentario: idComentario
                        }
                    })
                    .then(resolveresult3 => {
                        var respuesta = {
                            success: 'true',
                            user: resolveresult3
                        };
                        resolve(respuesta);
                    });
            });

        });


        /*
        readXlsxFile(fs.createReadStream('Book1.xlsx')).then((rows) => {
          console.log("pedro2");
          rows.forEach(element => {
              console.log("aaaaaasssss");
              console.log(element);
          });
      })
      */

        return p;
    },
    MostrarComentarios: function (idHerramienta, seleccion,iduser) {
        var p = new Promise(function (resolve, reject) {
            const comentarios = ComentarioPorHerramienta.findAll({
                where: {
                    IdHerramienta: idHerramienta,
                    Status: 0,
                    Estado: seleccion,
                    IdUsuario:iduser
                },
                attributes: ['IdComentario', 'PreClasificacion', 'Aspecto','tema', 'IdHerramienta', 'Status', 'Estado', 'Comentario']
            });
            comentarios.then(resolveresult1 => {
                //   var Selection = JSON.parse(resolveresult1.Usuarios);
                //console.log(Selection[0]);
                var respuesta = {
                    success: 'true',
                    cometarios: resolveresult1
                };
                resolve(respuesta);
            });

        });
        return p;
    },


};
