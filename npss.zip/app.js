var express = require('express');
var cors = require('cors');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(cors());
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With, Authorization');
  next();
});
//Controllers
var comentarios = require('./Controllers/Comentario').comentario;


//Comentarios

app.use(function(req, res, next) {
  console.log(`${req.method} request for '${req.url}'`);
  next();
});

app.post('/npsClassification/comentarios', function(req, res) {
  console.log("aasss");
  comentarios.create().then(function(_message) {
    res.send(_message);
  });
});
app.delete('/npsClassification/usuarios', function(req, res) {
    console.log("aa");
    comentarios.LLenadoDeUsuarios().then(function(_message) {
      res.send(_message);
    });
  });

  app.post('/npsClassification/distribucion', function(req, res) {
    console.log("aa");
    comentarios.Distribucion().then(function(_message) {
      res.send(_message);
    });
  });
  app.put('/npsClassification/comentarios/:idComentario',  function(req, res) {
      console.log(req.body);
    comentarios.Clasificar(req.params.idComentario, req.body).then(function(_response) {
      res.send(_response);
    });
  });

  app.get('/npsClassification/comentarios',  function(req, res) {
    console.log(req.body);
  comentarios.MostrarComentarios(req.body.idHerramienta, req.body.seleccion,req.body.iduser).then(function(_response) {
    res.send(_response);
  });
});
app.post('/npsClassification/csv', function(req, res) {
  comentarios.uploadToBlob(req.body.file, req.body.name).then(function(_message) {
    res.send(_message);
  });
});


/*
app.post('/uploadData/template2', function(req, res) {
 
  templates.create2(req.body.Name, req.body.Column,req.body.Location).then(function(_message) {
    res.send(_message);
  });
});
*/

var server = app.listen(process.env.PORT || 8080, function() {
  console.log(server.address());
});

module.exports = app;